/**
 * Service Worker do painel (PWA).
 *
 * SEGURANÇA: somente arquivos ESTÁTICOS do painel (HTML sem dados, CSS, JS,
 * ícones) são guardados em cache. Respostas da API (/api/), fotos enviadas
 * e qualquer requisição que não seja GET passam direto para a rede e NUNCA
 * são armazenadas — dados administrativos não ficam salvos no aparelho.
 *
 * CACHE_VERSION é trocada AUTOMATICAMENTE pelo scripts/publicar.py (hash dos
 * arquivos do painel) — não precisa mudar à mão.
 */
const CACHE_VERSION = 'rv-admin-deff44aa';
const STATIC_CACHE = `${CACHE_VERSION}-static`;
const FONT_CACHE = `${CACHE_VERSION}-fonts`;

const APP_SHELL = [
  './',
  './index.html',
  './login.html',
  './imoveis.html',
  './imovel-form.html',
  './categorias.html',
  './caracteristicas.html',
  './localidades.html',
  './configuracoes.html',
  './usuarios.html',
  './perfil.html',
  './trocar-senha.html',
  './offline.html',
  './manifest.json',
  './icons/icon-192.png?v=10ae9240',
  './icons/icon-512.png?v=cf8e5a2c',
  './icons/icon-maskable-full-512.png?v=cf8e5a2c',
  './icons/apple-touch-icon.png?v=1ce196f1',
  './icons/favicon-32.png?v=ea268c73',
  '../assets/images/logo-assinatura.webp?v=e1c58ccc',
  '../assets/images/marble-sm.webp?v=f8b576be',
  '../assets/images/marble.webp?v=061e2014',
  "./css/admin.css?v=46524e90",
  "./js/core/api.js?v=caea59d1",
  "./js/core/format.js?v=9404b4d7",
  "./js/core/gallery.js?v=8bfc33b8",
  "./js/core/icons.js?v=c12aff5b",
  "./js/core/layout.js?v=ed9850b4",
  "./js/core/money.js?v=3fdfd9a6",
  "./js/core/pwa.js?v=691994c7",
  "./js/core/ui.js?v=fb5bb849",
  "./js/pages/catalog.js?v=4d3f2f68",
  "./js/pages/dashboard.js?v=ef3d17b4",
  "./js/pages/first-access.js?v=9b224f9c",
  "./js/pages/locations.js?v=3142abf4",
  "./js/pages/login.js?v=76d3bb35",
  "./js/pages/profile.js?v=b91ff09c",
  "./js/pages/properties.js?v=24289166",
  "./js/pages/property-form.js?v=2cd467a9",
  "./js/pages/settings.js?v=c84e65d1",
  "./js/pages/users.js?v=6fde69db",
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => !k.startsWith(CACHE_VERSION)).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

function isApiOrUpload(url) {
  return url.pathname.includes('/api/') || url.pathname.includes('/uploads/') || url.pathname.includes('/install/');
}

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;                       // POST/uploads: sempre rede

  const url = new URL(request.url);

  // Fontes do Google: cache primeiro (arquivos públicos e imutáveis)
  if (url.origin === 'https://fonts.googleapis.com' || url.origin === 'https://fonts.gstatic.com') {
    event.respondWith(
      caches.open(FONT_CACHE).then(async (cache) => {
        const hit = await cache.match(request);
        if (hit) return hit;
        const res = await fetch(request);
        if (res.ok || res.type === 'opaque') cache.put(request, res.clone());
        return res;
      })
    );
    return;
  }

  if (url.origin !== self.location.origin) return;           // outros domínios (ex.: ViaCEP): rede
  if (isApiOrUpload(url)) return;                            // dados: NUNCA em cache

  // Páginas: rede primeiro (sempre a versão mais nova); sem internet → cache → offline.html
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((res) => {
          if (res.ok) {
            const copy = res.clone();
            caches.open(STATIC_CACHE).then((cache) => cache.put(url.pathname, copy));
          }
          return res;
        })
        .catch(async () => (await caches.match(url.pathname)) || (await caches.match('./offline.html')))
    );
    return;
  }

  // CSS, JS, ícones: responde do cache e atualiza em segundo plano
  event.respondWith(
    caches.open(STATIC_CACHE).then(async (cache) => {
      const cached = await cache.match(request);
      const network = fetch(request)
        .then((res) => {
          if (res.ok && res.type === 'basic') cache.put(request, res.clone());
          return res;
        })
        .catch(() => cached);
      return cached || network;
    })
  );
});

// Permite que a página peça atualização imediata
self.addEventListener('message', (event) => {
  if (event.data === 'skipWaiting') self.skipWaiting();
});
